﻿#include "Widget.h"
#include "ui_Widget.h"

Widget::Widget(QWidget *parent) :
   QWidget(parent),
   ui(new Ui::Widget)
{
   ui->setupUi(this);
}

Widget::~Widget()
{
   delete ui;
}

void Widget::on_btnCalculate_clicked()
{
}

void Widget::on_spinCount_valueChanged(int arg1)
{
}

void Widget::on_spinPrice_valueChanged(double arg1)
{
}
